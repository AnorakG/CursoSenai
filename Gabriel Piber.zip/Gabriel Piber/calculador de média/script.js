let n1 = Math.random()*10
let n2 = Math.random()*10
let n3 = Math.random()*10
let media = (n1+n2+n3)/3

console.log("Notas:", n1.toFixed(2),n2.toFixed(2),n3.toFixed(2))
if(media >= 7){
    console.log("Aluno aprovado =), Média: " + media.toFixed(2))
}
else if(media >= 3){
    console.log("Aluno em Recuperação :(, Média: " + media.toFixed(2))
}
else{
    console.log("Aluno reprovado >=(")
}
