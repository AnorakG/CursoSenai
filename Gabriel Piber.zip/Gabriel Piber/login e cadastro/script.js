let users = []
let objeto = {
    nome,
    senha,
}

function cadastrar(){
    console.log("cadastrar");
    let nome = document.getElementById("nome")
    let senha = document.getElementById("senha")

    users.push({nome: nome.value, senha: senha.value})
    localStorage.setItem("users", JSON.stringify(users))

    console.log(localStorage.getItem('users'))
}

function confirmar(){
    let usuarios = localStorage.getItem('users')    
    console.log (usuarios)

    nomeUsuario=document.getElementById('nomeUsuario')
    senhaUsuario=document.getElementById('senhaUsuario')

    if(senhaUsuario != usuarios.senha && nomeUsuario != usuarios.nome){
        alert('vai se cadastrar')
    }else{
        alert('você está logado')
    }
}