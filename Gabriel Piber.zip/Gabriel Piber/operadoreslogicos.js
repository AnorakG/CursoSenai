//console.log(1==1 && 2==2);
//console.log(1==1 && 2==1);
//console.log(2==1 && 2==2);
//console.log(1>=0 && 2<3 && 4>3);

//console.log(1==1 || 2>3);

//let isMaior = 4>2
//console.log(isMaior);
//console.log(!isMaior)

let a = Math.floor(Math.random()*10)
let b = Math.floor(Math.random()*10)

if(a<=b){
    console.log("Este é o seu menor número(a):"+a)
}
else{
    console.log("Este é o seu menor número(b):"+b)
}
