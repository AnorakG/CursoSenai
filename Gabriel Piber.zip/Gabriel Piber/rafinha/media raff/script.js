function calcularMedia(){
    let nota1 = Number(document.getElementById("inpNota1").value)
    let nota2 = Number(document.getElementById("inpNota2").value)
    let nota3 = Number(document.getElementById("inpNota3").value)

    let media = ((nota1 + nota2 + nota3)/3).toFixed(2)

    if(media>=6.00){
        media += "<br> Você está aprovado =)"
    }else{
        media += "<br> Você reprovou >=("
    }
    document.getElementById("resultado").innerHTML = "Sua média é: "+ media
}