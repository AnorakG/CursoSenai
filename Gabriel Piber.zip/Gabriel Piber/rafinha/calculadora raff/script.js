let primeiro = document.getElementById("inpPrimeiro")
let segundo = document.getElementById("inpSegundo")

function somar(){
    let soma = Number(primeiro.value) + Number(segundo.value)
    document.getElementById('resultado').innerHTML = soma
}
function subtrair(){
    let subtração = Number(primeiro.value) - Number(segundo.value)
    document.getElementById('resultado').innerHTML = subtração
}
function multiplicar(){
    let multiplicação = Number(primeiro.value) * Number(segundo.value)
    document.getElementById('resultado').innerHTML = multiplicação
}
function dividir(){
    let divisão = Number(primeiro.value) / Number(segundo.value)
    document.getElementById('resultado').innerHTML = divisão
}