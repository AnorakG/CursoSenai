let numero = 0
while(numero!=3){
    numero = Math.floor(Math.random()*100)
    console.log(numero)
}