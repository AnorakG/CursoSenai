let v1 = 20
let v2 = 10

if(v1 <= v2){
    console.log('V1:',v1,'V2:', v2)
}
else{
    console.log('V2:',v1,'V1:', v2)
}