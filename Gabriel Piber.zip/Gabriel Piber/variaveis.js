//console.log("Nomes:")

//let nome= "João"
//let nome2= "Gabriel"

//let numeroLetras = nome.length 
//let numeroLetras2 = nome2.length 

//console.log(nome, numeroLetras)
//console.log(nome2, numeroLetras2)

let numero1 = 10
let numeroString1 = '10'
console.log(numero1 == numeroString1)
console.log(numero1 === numeroString1)

let x = 20
let y = 110
let resultado = x+y

console.log(resultado)