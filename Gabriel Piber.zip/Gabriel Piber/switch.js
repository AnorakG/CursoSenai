const opcao = "uva"

switch(opcao){
    case "laranja":
        console.log("preço da laranja R$ 3,50")
        break
    case "pera":
        console.log("preço da pera R$ 2,50")
        break
    case "uva":
        console.log("preço da uva R$ 3,89")
        break
    default:
        console.log("produto non ecziste")
        break
}