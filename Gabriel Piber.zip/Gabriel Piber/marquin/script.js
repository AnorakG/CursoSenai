function somar(){
    let x=document.getElementById("x").value
    let y=document.getElementById("y").value
    
    resultado=parseFloat(x)+parseFloat(y)
  
    document.getElementById("r").value = resultado
}