const dias = ["domingo","segunda","terça","quarta","quinta","sexta","sabado"]
dias.forEach((indice)=>console.log(indice))

console.log("")

for(let i = 0;i<7; i++){
    console.log(dias[i])
}