let a = Math.floor(Math.random()*10)
let b = Math.floor(Math.random()*10)

console.log(a)
console.log(b)

console.log(a,">",b, a>b)
console.log(a,"<",b, a<b)

//console.log(a==b)
//console.log("a"==b)
//console.log("a"===b)
//console.log(a>b)
//console.log(a<b)
//console.log(a>=b)
//console.log(a<=b)
//console.log(a!=b)