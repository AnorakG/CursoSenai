let preco = 0.50
console.log(preco)
while(preco<=9.50){
    preco *= 1.05
    console.log(preco.toFixed(2))
}