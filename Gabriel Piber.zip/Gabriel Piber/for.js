n = 100
for(i=0;i<n;i+=2){
    console.log(i+2)
}