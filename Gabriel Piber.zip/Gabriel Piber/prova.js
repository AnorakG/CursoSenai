let opc = 1
let valor = 100
let resultado = 0

switch (opc){
    case 1:
        resultado=valor*0.10
        console.log(resultado)
        break
    case 2:
        resultado = valor*0.20
        console.log(resultado)
        break
    default:
        console.log("opção invalida")
}